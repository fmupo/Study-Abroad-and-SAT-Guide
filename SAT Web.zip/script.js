// Add JavaScript code for your web site here and call it from index.html.
// Smooth Scroll for Menu Buttons
document.querySelectorAll(".menu button").forEach(button => {
  button.addEventListener("click", () => {
    const targetId = button.getAttribute("data-target");
    const section = document.getElementById(targetId);
    if (section) {
      section.scrollIntoView({ behavior: "smooth" });
    }
  });
});

// Dark Mode Toggle
const toggle = document.getElementById("darkModeToggle");
toggle.addEventListener("click", () => {
  document.body.classList.toggle("dark-toggle");
  toggle.textContent = document.body.classList.contains("dark-toggle")
    ? "☀️ Light Mode"
    : "🌙 Dark Mode";
})